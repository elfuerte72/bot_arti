import logging
from pathlib import Path

import openai

from config.settings import settings
from voice.voice_utils import convert_audio_format, remove_file_async

logger = logging.getLogger(__name__)


async def transcribe_audio(file_path: str) -> str:
    """
    Transcribe audio file to text using OpenAI Whisper API.
    
    Args:
        file_path: Path to the audio file (OGG, MP3, etc.)
        
    Returns:
        Transcribed text
    """
    file_path = Path(file_path)
    converted_file_path = None

    try:
        # Check if API key is available
        if not settings.OPENAI_API_KEY:
            logger.error("OpenAI API key is not available")
            return "Не удалось распознать голосовое сообщение (API ключ не найден)"

        # Set OpenAI API key
        openai.api_key = settings.OPENAI_API_KEY
        
        # Convert to MP3 if needed
        if file_path.suffix.lower() != '.mp3':
            logger.info(f"Converting {file_path.suffix} to MP3")
            converted_file_path = await convert_audio_format(file_path, "mp3")
            audio_file_path = converted_file_path
        else:
            audio_file_path = file_path
        
        # Create client and transcribe
        client = openai.AsyncOpenAI(api_key=settings.OPENAI_API_KEY)
        
        # Read file as bytes and send to OpenAI API
        async def _transcribe():
            with open(audio_file_path, "rb") as audio_file:
                result = await client.audio.transcriptions.create(
                    model="whisper-1",
                    file=audio_file,
                    language="ru"  # Default to Russian, can be changed
                )
                return result.text
        
        # Perform transcription
        text = await _transcribe()
        
        # Log and return result
        logger.info(f"Transcribed audio: {text[:30]}...")
        return text
        
    except Exception as e:
        logger.exception(f"Error transcribing audio: {e}")
        return f"Ошибка распознавания: {str(e)}"
        
    finally:
        # Clean up converted file if it exists
        if converted_file_path:
            await remove_file_async(converted_file_path)


async def process_voice_message(file_path: str) -> str:
    """
    Process voice message for the bot.
    This function can be extended to add pre/post-processing.
    
    Args:
        file_path: Path to the voice message file
        
    Returns:
        Transcribed text
    """
    # Basic implementation just calls transcribe_audio
    return await transcribe_audio(file_path)
