import os
import logging
import re
import uuid
from pathlib import Path
import aiofiles
import asyncio
from datetime import datetime

from pydub import AudioSegment


logger = logging.getLogger(__name__)


def normalize_filename(filename: str) -> str:
    """
    Normalize a filename by removing non-alphanumeric characters.
    
    Args:
        filename: Original filename
        
    Returns:
        Normalized filename
    """
    # Remove non-alphanumeric characters except for extension
    base_name, ext = os.path.splitext(filename)
    base_name = re.sub(r'[^\w\-_]', '_', base_name)
    return f"{base_name}{ext}"


def generate_temp_filename(extension: str = ".mp3", prefix: str = "voice_") -> str:
    """
    Generate a unique temporary filename.
    
    Args:
        extension: File extension (default: .mp3)
        prefix: Filename prefix (default: voice_)
        
    Returns:
        Unique filename
    """
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    random_id = str(uuid.uuid4())[:8]
    return f"{prefix}{timestamp}_{random_id}{extension}"


async def save_file_async(data: bytes, filepath: Path) -> Path:
    """
    Save binary data to a file asynchronously.
    
    Args:
        data: Binary data to save
        filepath: Path to save to
        
    Returns:
        Path to the saved file
    """
    filepath.parent.mkdir(parents=True, exist_ok=True)
    async with aiofiles.open(filepath, 'wb') as file:
        await file.write(data)
    return filepath


async def remove_file_async(filepath: Path) -> None:
    """
    Remove a file asynchronously.
    
    Args:
        filepath: Path to the file to remove
    """
    try:
        if os.path.exists(filepath):
            os.remove(filepath)
            logger.debug(f"Removed temporary file: {filepath}")
    except Exception as e:
        logger.error(f"Error removing file {filepath}: {e}")


async def convert_audio_format(source_path: Path, target_format: str = "mp3") -> Path:
    """
    Convert audio file to a different format.
    
    Args:
        source_path: Path to the source audio file
        target_format: Target format (default: mp3)
        
    Returns:
        Path to the converted file
    """
    target_path = source_path.with_suffix(f".{target_format}")
    
    # Use a semaphore or run in a process pool to avoid blocking
    def _convert():
        audio = AudioSegment.from_file(str(source_path))
        audio.export(str(target_path), format=target_format)
    
    # Run CPU-intensive operation in a separate thread pool
    await asyncio.to_thread(_convert)
    return target_path


async def trim_audio(source_path: Path, max_duration_ms: int = 60000) -> Path:
    """
    Trim audio file to maximum duration.
    
    Args:
        source_path: Path to the source audio file
        max_duration_ms: Maximum duration in milliseconds
        
    Returns:
        Path to the trimmed file (same as source if no trimming needed)
    """
    audio = await asyncio.to_thread(AudioSegment.from_file, str(source_path))
    
    if len(audio) <= max_duration_ms:
        return source_path
    
    trimmed_audio = audio[:max_duration_ms]
    target_path = source_path.with_name(f"trimmed_{source_path.name}")
    
    await asyncio.to_thread(
        trimmed_audio.export, str(target_path), format=source_path.suffix[1:]
    )
    return target_path
