import os
import uuid

from aiogram import Router, F
from aiogram.types import Message, FSInputFile
from aiogram.filters import Command

from config.settings import settings
from core.command_router import handle_command
from voice.speech_to_text import process_voice_message
from voice.text_to_speech import synthesize_response

# Create routers
router = Router()
cmd_router = Router()


@cmd_router.message(Command("start"))
async def cmd_start(message: Message) -> None:
    """Handle /start command."""
    await message.answer(
        "Привет! Я бот для управления презентациями. "
        "Отправляй мне текстовые или голосовые команды "
        "для управления слайдами.\n\n"
        "Примеры команд: 'следующий слайд', 'назад', 'начать презентацию'."
    )


@cmd_router.message(Command("help"))
async def cmd_help(message: Message) -> None:
    """Handle /help command."""
    help_text = (
        "📝 <b>Текстовые команды:</b>\n"
        "- следующий слайд\n"
        "- предыдущий слайд\n"
        "- пауза\n"
        "- продолжить\n"
        "- начать презентацию\n"
        "- завершить презентацию\n"
        "- статус\n\n"
        "🎤 <b>Голосовые команды:</b>\n"
        "Вы также можете отправить голосовое сообщение с любой из команд выше."
    )
    await message.answer(help_text, parse_mode="HTML")


@router.message(F.voice)
async def voice_message_handler(message: Message) -> None:
    """
    Handle voice messages from the user.
    
    Download, save to a temp file, and pass to the STT service.
    """
    # Create unique file name for voice message
    voice_file_name = f"{uuid.uuid4()}.ogg"
    voice_file_path = settings.VOICE_TEMP_PATH / voice_file_name
    
    # Download voice message
    await message.bot.download(
        message.voice,
        destination=voice_file_path
    )
    
    try:
        # Process voice with STT
        text = await process_voice_message(voice_file_path)
        
        # Process the command
        result = await handle_command(text)
        
        # Prepare response text
        response_text = f"Распознано: \"{text}\"\n\n"
        
        # Add execution details if available
        if "execution_result" in result:
            exec_result = result["execution_result"]
            if exec_result["success"]:
                response_text += f"✅ {exec_result['message']}"
            else:
                response_text += f"❌ {exec_result['message']}"
        else:
            response_text += (
                f"Команда: {result['action']} "
                f"(уверенность: {result['confidence']:.2f})"
            )
        
        # Reply with text response
        await message.reply(response_text)
        
        # Generate voice response if command was executed
        if (result["confidence"] > 0.8 and 
                "execution_result" in result):
            try:
                exec_result = result["execution_result"]
                voice_response = await synthesize_response(
                    exec_result["message"]
                )
                
                # Send voice message
                voice_file = FSInputFile(voice_response)
                await message.answer_voice(voice_file)
                
                # Cleanup voice file
                os.remove(voice_response)
            except Exception:
                # Silently fail with voice response, we already sent text
                pass
    
    finally:
        # Clean up the temporary file
        if os.path.exists(voice_file_path):
            os.remove(voice_file_path)


@router.message(F.text)
async def text_message_handler(message: Message) -> None:
    """Handle text messages and process as commands."""
    # Process the command
    result = await handle_command(message.text)
    
    # If command is recognized with sufficient confidence
    if result["confidence"] > 0.7:
        # Prepare response based on execution result
        if "execution_result" in result:
            exec_result = result["execution_result"]
            if exec_result["success"]:
                response_text = f"✅ {exec_result['message']}"
            else:
                response_text = f"❌ {exec_result['message']}"
            
            await message.reply(response_text)
            
            # Optional voice response for successful commands
            if exec_result["success"] and result["confidence"] > 0.85:
                try:
                    voice_response = await synthesize_response(
                        exec_result["message"]
                    )
                    voice_file = FSInputFile(voice_response)
                    await message.answer_voice(voice_file)
                    os.remove(voice_response)
                except Exception:
                    # Silently fail voice response
                    pass
        else:
            await message.reply(
                f"Выполняю команду: {result['action']} "
                f"(уверенность: {result['confidence']:.2f})"
            )
    else:
        await message.reply(
            "Не удалось распознать команду. Пожалуйста, попробуйте еще раз "
            "или используйте /help для просмотра доступных команд."
        )
