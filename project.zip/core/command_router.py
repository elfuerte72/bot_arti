from typing import Dict, Any, List, Tuple
import re
import logging

from slides import keynote_controller

logger = logging.getLogger(__name__)

# Command mapping with keywords and synonyms
COMMAND_PATTERNS: Dict[str, List[Tuple[str, float]]] = {
    "next_slide": [
        (r"\b(next|forward|следующий|вперед|далее)\s+(slide|слайд)\b", 0.95),
        (r"\b(next|forward|следующий|вперед|далее)\b", 0.85),
    ],
    "previous_slide": [
        (r"\b(previous|back|назад|предыдущий)\s+(slide|слайд)\b", 0.95),
        (r"\b(previous|back|назад|предыдущий)\b", 0.85),
    ],
    "pause": [
        (r"\b(pause|stop|пауза|стоп|остановить)\b", 0.9),
    ],
    "continue": [
        (r"\b(continue|resume|продолжить|продолжай|возобновить)\b", 0.9),
    ],
    "start_presentation": [
        (r"\b(start|begin|начать|запустить)\s+"
         r"(presentation|презентацию|показ)\b", 0.95),
        (r"\b(begin|start)\b", 0.8),
    ],
    "end_presentation": [
        (r"\b(end|finish|закончить|завершить)\s+"
         r"(presentation|презентацию|показ)\b", 0.95),
        (r"\b(end|finish|exit|quit|выход|выйти)\b", 0.8),
    ],
    "status": [
        (r"\b(status|статус|состояние|текущий слайд)\b", 0.9),
    ],
}

# Mapping from command name to controller function
COMMAND_FUNCTIONS = {
    "next_slide": keynote_controller.next_slide,
    "previous_slide": keynote_controller.previous_slide,
    "pause": keynote_controller.pause_presentation,
    "continue": keynote_controller.pause_presentation,
    "start_presentation": keynote_controller.start_presentation,
    "end_presentation": keynote_controller.end_presentation,
    "status": keynote_controller.get_presentation_status,
}


async def handle_command(text: str) -> Dict[str, Any]:
    """
    Parse and route user commands.
    
    Args:
        text: The text to parse
        
    Returns:
        Dictionary with action, confidence score, and execution result
    """
    # Normalize text - lowercase and strip extra whitespace
    normalized_text = text.lower().strip()
    
    highest_confidence = 0.0
    best_action = "unknown"
    
    # Check each command pattern
    for action, patterns in COMMAND_PATTERNS.items():
        for pattern, confidence in patterns:
            if re.search(pattern, normalized_text):
                if confidence > highest_confidence:
                    highest_confidence = confidence
                    best_action = action
    
    result = {
        "action": best_action,
        "confidence": highest_confidence,
        "original_text": text
    }
    
    # Execute the command if it's recognized with sufficient confidence
    if highest_confidence > 0.7 and best_action in COMMAND_FUNCTIONS:
        try:
            # Get the corresponding function
            command_func = COMMAND_FUNCTIONS[best_action]
            
            # Execute the command
            logger.info(f"Executing command: {best_action}")
            command_result = await command_func()
            result["execution_result"] = command_result
            
        except Exception as e:
            logger.exception(f"Error executing command {best_action}: {e}")
            result["execution_error"] = str(e)
    
    return result
